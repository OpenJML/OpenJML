package util;

public interface ReferenceIterator {

	public boolean hasNext();

	public int next();

}
