package util;

public interface Compareable {
	byte compareTo(Compareable right);
}
