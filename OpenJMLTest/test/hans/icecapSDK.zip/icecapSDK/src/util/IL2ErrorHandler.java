package util;

public interface IL2ErrorHandler {

	void errorOccurred(String errorString, byte offendingByte);

}
