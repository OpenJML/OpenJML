package javax.safetycritical;

final class ScjIllegalArgumentException extends IllegalArgumentException {

	private static final long serialVersionUID = 1L;
	
	boolean standardThrowable() {
		return true;
	}

}
