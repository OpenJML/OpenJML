package javax.realtime;

public class BoundAsyncLongEventHandler extends AsyncLongEventHandler 
	implements BoundAbstractAsyncEventHandler {

}
