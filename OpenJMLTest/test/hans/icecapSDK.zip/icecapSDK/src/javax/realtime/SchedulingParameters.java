package javax.realtime;

public abstract class SchedulingParameters implements Cloneable {

}
