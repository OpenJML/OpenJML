package test.V850ES;

public class HelloV850 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		devices.System.delay(1000);
	}
}
