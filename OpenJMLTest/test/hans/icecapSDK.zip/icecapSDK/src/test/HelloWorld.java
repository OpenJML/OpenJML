package test;

public class HelloWorld {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		devices.Console.println("Helloworld!");
	}

}
