package vm;

public class HardwareObject {
	protected Address address;

	public HardwareObject(Address address) {
		this.address = address;
	}
}