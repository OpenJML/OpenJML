package vm;

public interface StackAnalyser {

	void addStack(int[] stack);

	void reportStackUsage();

}
