package icecaptools;

public @interface IcecapCompileMe {

}
