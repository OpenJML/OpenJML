package icecaptools;

public @interface IcecapVolatile {

	String value();

}
