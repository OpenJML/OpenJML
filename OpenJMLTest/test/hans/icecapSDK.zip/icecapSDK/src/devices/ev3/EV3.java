package devices.ev3;

public class EV3 {

	public static native void sleep(int milliseconds);

}
