package devices.ev3;

public class Port {
	protected byte port;

	public byte getPort() {
		return port;
	}
}
