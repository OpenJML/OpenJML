package devices;

public interface Writer {

	void write(byte[] bytes, short length);

}
