package test;

public abstract class BasicJMLTest {

	public abstract String getJMLAnnotationCommand();
}
