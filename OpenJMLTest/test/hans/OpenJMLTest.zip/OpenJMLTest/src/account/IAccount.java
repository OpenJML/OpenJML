package account;

public interface IAccount {

  public abstract int balance();
}
